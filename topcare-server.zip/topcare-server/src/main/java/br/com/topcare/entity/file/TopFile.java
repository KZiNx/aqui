package br.com.topcare.entity.file;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class TopFile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Lob
    @Column(nullable = false)
    private byte[] image;
    @Column(nullable = false)
    private String fileName;
    private String originalName;
    private String fileType;
    @Column(nullable = false)
    private long size;


}
