package br.com.topcare.entity.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;


@Data
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class TopUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 100)
    private String userName;
    @Column(nullable = false, length = 100, unique = true)
    private String email;
    @Column(nullable = false)
    @JsonIgnore
    @ToString.Exclude
    private String userPassword;
    @Column(nullable = false)
    private Long cpf;
    private Long cellphone;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(nullable = false)
    private TopUser image;

}
