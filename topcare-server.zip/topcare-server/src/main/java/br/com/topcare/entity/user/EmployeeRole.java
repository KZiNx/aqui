package br.com.topcare.entity.user;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EmployeeRole {
    STANDARD("Standard"),
    MANAGER("Gerente"),
    ADMIN("Admin");

    private final String name;

}
