package br.com.topcare.entity.order;


import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum OrderStatus {
    WAITING_PAYMENT("Aguardando pagamento"),
    IN_PREPARATION("Em preparo"),
    IN_TRANSIT("Em trânsito"),
    DELIVERED("Entregue");

    private final String name;
}
