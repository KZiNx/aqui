package br.com.topcare.entity.user;

import br.com.topcare.entity.order.Address;
import br.com.topcare.entity.order.Cart;
import br.com.topcare.entity.order.TopOrder;
import br.com.topcare.entity.product.Product;
import br.com.topcare.entity.scheduling.Pet;
import br.com.topcare.entity.scheduling.Scheduling;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Customer extends TopUser {
    @ManyToMany
    @JoinTable(name = "customer_product",
    joinColumns = @JoinColumn(name = "customer_id"),
    inverseJoinColumns = @JoinColumn(name = "product_id"))
    private List<Product> favorites;
    @OneToMany
    @JoinColumn(nullable = false, name = "customer_id")
    private List<Address> addresses;
    @OneToMany
    @JoinColumn(nullable = false, name = "customer_id")
    private List<Cart> carts;
    @OneToMany
    @JoinColumn(nullable = false, name = "customer_id")
    private List<TopOrder> topOrders;
    @OneToMany
    @JoinColumn(nullable = false, name = "customer_id")
    private List<Pet> pets;
    @OneToMany
    @JoinColumn(nullable = false, name = "customer_id")
    private List<Scheduling> schedulings;
}
