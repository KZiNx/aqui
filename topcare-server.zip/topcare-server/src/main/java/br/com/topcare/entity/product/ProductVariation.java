package br.com.topcare.entity.product;

import br.com.topcare.entity.file.ProductVariationTopFile;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class ProductVariation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(length = 20, nullable = false)
    private String variationName;
    @Column(nullable = false)
    private Double price;
    @Column(nullable = false)
    private Integer stock;
    private Boolean defaultVariation;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "product_variation_id")
    private List<ProductVariationTopFile> images;
}
