package br.com.topcare.entity.branch;

import br.com.topcare.entity.file.TopFile;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Branch {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 100)
    private String branchName;
    @Column(nullable = false, length = 200)
    private String address;
    @Column(nullable = false)
    private Long cellphone;
    @Column(nullable = false)
    private Long cep;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(nullable = false)
    private TopFile image;
}
