package br.com.topcare.repository.order;


import br.com.topcare.entity.order.TopOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TopOrderRepository extends JpaRepository<TopOrder, Long> {
}
