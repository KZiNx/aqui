package br.com.topcare.entity.order;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ShippingType {
    STANDARD("Padrão", 0.0),
    FAST("Rápido",  22.99),
    EXPRESS("Expresso", 24.99);

    private final String name;
    private final Double price;
}
