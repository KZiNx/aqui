package br.com.topcare.entity.user;

import br.com.topcare.entity.branch.Branch;
import br.com.topcare.entity.scheduling.Scheduling;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Employee extends TopUser {
    @Enumerated(EnumType.STRING)
    private EmployeeRole employeeRole;
    @ManyToOne
    @JoinColumn(nullable = false)
    private Branch branch;
    @OneToMany
    @JoinColumn(nullable = false, name = "employee_id")
    private List<Scheduling> schedulings;
}
