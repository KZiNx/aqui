package br.com.topcare.entity.product;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(length = 80, nullable = false)
    private String productName;
    @Column(length = 2000)
    private String productDescription;
    private Double rating;
    @Column(nullable = false)
    private String petMarker;
    @Column(nullable = false)
    private String ageMarker;
    private Integer discount;
    private LocalDateTime discountStart;
    private LocalDateTime discountEnd;
    @ManyToOne
    @JoinColumn(nullable = false)
    private Brand brand;
    @OneToMany(cascade = CascadeType.PERSIST)
    @JoinColumn(nullable = false, name = "product_id")
    private List<Specification> specifications;
    @OneToMany
    @JoinColumn(nullable = false, name = "product_id")
    private List<Avaliation> avaliations;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(nullable = false, name = "product_id")
    private List<ProductVariation> productVariations;
}
