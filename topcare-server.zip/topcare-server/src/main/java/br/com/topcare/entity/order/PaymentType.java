package br.com.topcare.entity.order;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PaymentType {
    CREDIT_CARD("Cartão de crédito"),
    BANK_SLIP("Boleto"),
    PIX("Pix");

    private final String name;
}
