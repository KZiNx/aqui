package br.com.topcare.repository.scheduling;

import br.com.topcare.entity.scheduling.TopService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TopServiceRepository extends JpaRepository<TopService, Long> {
}
