package br.com.topcare.entity.product;

import br.com.topcare.entity.file.TopFile;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Brand {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(length = 40, nullable = false)
    private String brandName;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(nullable = false)
    private TopFile image;
}
