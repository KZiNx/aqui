package br.com.topcare.entity.scheduling;


import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Genre {
    FEMALE("Fêmea"),
    MALE("Macho");

    private final String name;
}
