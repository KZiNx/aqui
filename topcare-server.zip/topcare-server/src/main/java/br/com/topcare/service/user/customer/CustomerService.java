package br.com.topcare.service.user.customer;

import br.com.topcare.controller.user.dto.CustomerPostDTO;
import br.com.topcare.entity.user.Customer;
import br.com.topcare.entity.user.TopUser;
import br.com.topcare.repository.user.TopUserRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.Optional;

@AllArgsConstructor
@Service
public class CustomerService implements CustomerServiceInterface {
    private TopUserRepository repository;

    @Override
    public Customer createCustomer(CustomerPostDTO customerPostDTO) {
        Customer customer = new Customer();
        BeanUtils.copyProperties(customerPostDTO, customer);
        return repository.save(customer);
    }
}
