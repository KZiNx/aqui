package br.com.topcare.service.user.topUser;

import br.com.topcare.entity.user.TopUser;
import br.com.topcare.exception.user.InvalidLoginCredentialsException;
import br.com.topcare.repository.user.TopUserRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.NoSuchElementException;
import java.util.Optional;

@AllArgsConstructor
@Service
public class TopUserService implements TopUserServiceInterface {
    private TopUserRepository repository;

    @Override
    public TopUser login(String userName, String userPassword) throws NoSuchElementException, InvalidLoginCredentialsException {
        Optional<TopUser> topUserOptional = repository.findByUserName(userName);
        if (topUserOptional.isEmpty()) {
            throw new NoSuchElementException();
        }
        TopUser topUser = topUserOptional.get();
        if (!topUser.getUserPassword().equals(userPassword)) {
            throw new InvalidLoginCredentialsException();
        }
        return topUser;
    }
}
