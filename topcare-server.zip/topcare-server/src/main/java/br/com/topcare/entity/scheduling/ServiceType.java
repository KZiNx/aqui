package br.com.topcare.entity.scheduling;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ServiceType {
    VETERINARY("Veterinária"),
    BATHING_AND_GROOMING("Banho e tosa");

    private String name;
}
