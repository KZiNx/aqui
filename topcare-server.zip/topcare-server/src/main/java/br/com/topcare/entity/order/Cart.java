package br.com.topcare.entity.order;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ShippingType shippingType;
    @Column(nullable = false)
    private Double subtotal;
    @Column(nullable = false)
    private Double total;
    @ManyToOne
    private Address address;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(nullable = false)
    private List<CartItem> cartItems;
}
