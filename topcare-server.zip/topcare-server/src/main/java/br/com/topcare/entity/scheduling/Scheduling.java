package br.com.topcare.entity.scheduling;

import br.com.topcare.entity.branch.Branch;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Scheduling {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private LocalDateTime schedulingDate;
    @Column(nullable = false)
    private Double price;
    private boolean accomplished;
    private String note;
    @ManyToOne
    @JoinColumn(nullable = false)
    private Pet pet;
    @ManyToOne
    @JoinColumn(nullable = false)
    private Branch branch;
    @ManyToOne
    private ServiceIncrement serviceIncrement;
    @ManyToOne
    @JoinColumn(nullable = false)
    private TopService topService;
}
