package br.com.topcare.service.user.topUser;

import br.com.topcare.entity.user.TopUser;
import br.com.topcare.exception.user.InvalidLoginCredentialsException;
import org.springframework.stereotype.Service;

import java.util.NoSuchElementException;

@Service
public interface TopUserServiceInterface {
    TopUser login(String userName, String userPassword)  throws NoSuchElementException, InvalidLoginCredentialsException;
}
