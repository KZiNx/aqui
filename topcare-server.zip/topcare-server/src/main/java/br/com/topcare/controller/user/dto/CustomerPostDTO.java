package br.com.topcare.controller.user.dto;


public record CustomerPostDTO(String userName, String email, String userPassword, Long cpf, Long cellphone) {
}
