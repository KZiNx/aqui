package br.com.topcare.entity.scheduling;

import br.com.topcare.entity.file.TopFile;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Pet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 50)
    private String animalName;
    @Column(nullable = false)
    private LocalDate dateOfBirth;
    private Double weight;
    private boolean neutered;
    @Column(length = 200)
    private String observation;
    @Enumerated(EnumType.STRING)
    private Genre genre;
    @OneToOne(cascade = CascadeType.ALL)
    private TopFile topFile;
    @ManyToOne
    @JoinColumn(nullable = false)
    private Animal animal;
    @ManyToOne
    private Breed breed;
}
