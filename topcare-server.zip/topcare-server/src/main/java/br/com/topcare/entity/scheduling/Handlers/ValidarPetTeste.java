package br.com.topcare.entity.scheduling.Handlers;

import java.time.LocalDate;

import br.com.topcare.entity.scheduling.Genre;
import br.com.topcare.entity.scheduling.Pet;


public class ValidarPetTeste {
    public static void main(String[] args) {
        ValidarPetHandler nomeHandler = new NomeValidarHandler();
        ValidarPetHandler nascimentoHandler = new NascimentoValidacaoHandler();
        ValidarPetHandler pesoHandler = new PesoValidarHandler();

        nomeHandler.setNextHandler(nascimentoHandler);
        nascimentoHandler.setNextHandler(pesoHandler);

        Pet pet = new Pet();
        pet.setAnimalName("dawd");
        pet.setDateOfBirth(LocalDate.of(2023, 5, 10));
        pet.setWeight(96.8);
        pet.setNeutered(true);
        pet.setObservation("");
        pet.setGenre(Genre.MALE);

        try {
            nomeHandler.handle(pet);
            System.out.println("o pet é valido");
        } catch (IllegalArgumentException e) {
            System.err.println("erro na validação: " + e.getMessage());
        }
    }
}