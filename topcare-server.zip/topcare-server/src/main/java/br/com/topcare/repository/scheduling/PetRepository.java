package br.com.topcare.repository.scheduling;

import br.com.topcare.entity.scheduling.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PetRepository extends JpaRepository<Pet, Long> {
}
