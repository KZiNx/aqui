package br.com.topcare.entity.scheduling.Handlers;

import br.com.topcare.entity.scheduling.Pet;

public class NomeValidarHandler extends ValidarPetHandler {
    @Override
    public void handle(Pet pet) {
        if (pet.getAnimalName() == null || pet.getAnimalName().isEmpty()) {
            throw new IllegalArgumentException("Nome nao pode ser vazio");
        }
        if (nextHandler != null) {
            nextHandler.handle(pet);
        }
    }
}