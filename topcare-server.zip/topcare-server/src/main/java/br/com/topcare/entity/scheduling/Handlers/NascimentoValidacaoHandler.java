package br.com.topcare.entity.scheduling.Handlers;

import java.time.LocalDate;

import br.com.topcare.entity.scheduling.Pet;

public class NascimentoValidacaoHandler extends ValidarPetHandler {
    @Override
    public void handle(Pet pet) {
        if (pet.getDateOfBirth() == null || pet.getDateOfBirth().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("data invalida");
        }
        if (nextHandler != null) {
            nextHandler.handle(pet);
        }
    }
}
