package br.com.topcare.entity.scheduling.Handlers;

import br.com.topcare.entity.scheduling.Pet;

public abstract class ValidarPetHandler {
    protected ValidarPetHandler nextHandler;

    public void setNextHandler(ValidarPetHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public abstract void handle(Pet pet);
}
