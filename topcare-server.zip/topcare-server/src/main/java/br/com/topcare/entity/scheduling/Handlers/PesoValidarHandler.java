package br.com.topcare.entity.scheduling.Handlers;

import br.com.topcare.entity.scheduling.Pet;

public class PesoValidarHandler extends ValidarPetHandler {
    @Override
    public void handle(Pet pet) {
        if (pet.getWeight() != null && pet.getWeight() < 0) {
            throw new IllegalArgumentException("O peso nao pode ser negativo");
        }
        if (nextHandler != null) {
            nextHandler.handle(pet);
        }
    }
}
