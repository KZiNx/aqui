package br.com.topcare.exception.user;

public class InvalidLoginCredentialsException extends Exception {
    public InvalidLoginCredentialsException() {
        super("Credencias de login inválidas");
    }
}
