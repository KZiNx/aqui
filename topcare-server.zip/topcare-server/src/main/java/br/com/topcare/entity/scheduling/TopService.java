package br.com.topcare.entity.scheduling;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class TopService {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 50)
    private String serviceName;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ServiceType serviceType;
    @Column(nullable = false)
    private Double basePrice;
    @ManyToMany
    @JoinTable(name = "top_service_animal",
    joinColumns = @JoinColumn(nullable = false, name = "top_service_id"),
    inverseJoinColumns = @JoinColumn(nullable = false, name = "animal_id"))
    private List<Animal> animals;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(nullable = false)
    private List<ServiceIncrement> serviceIncrements;
}
