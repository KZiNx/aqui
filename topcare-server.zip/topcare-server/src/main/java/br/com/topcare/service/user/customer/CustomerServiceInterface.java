package br.com.topcare.service.user.customer;

import br.com.topcare.controller.user.dto.CustomerPostDTO;
import br.com.topcare.entity.user.Customer;
import org.springframework.stereotype.Service;

@Service
public interface CustomerServiceInterface {
    Customer createCustomer(CustomerPostDTO customerPostDTO);
}
