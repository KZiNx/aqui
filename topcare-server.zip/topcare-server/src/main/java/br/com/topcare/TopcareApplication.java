package br.com.topcare;

import br.com.topcare.entity.product.Product;
import jakarta.annotation.PostConstruct;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.multipart.MultipartFile;

@SpringBootApplication
public class TopcareApplication {

	public static void main(String[] args) {
		SpringApplication.run(TopcareApplication.class, args);
	}

	@PostConstruct
	public static void teste() {
		Product product = new Product();
	}
}
