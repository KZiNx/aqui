package src;

public abstract class Iprocesso {
    protected Iprocesso iprocesso;

    public void setNextHandler(Iprocesso iprocesso) {
        this.iprocesso = iprocesso;
    }

    public abstract void runiprocesso();
}