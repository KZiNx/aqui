package src;

public class Moto extends Iprocesso {
    @Override
    public void runiprocesso() {
        System.out.println("Cortando giro... (Processo3)");

        if (iprocesso != null) {
            iprocesso.runiprocesso();
        }


    }
}