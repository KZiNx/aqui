package src;

public class Exemplo {

    public static void main(String args[]) {
        Iprocesso processo1 = new Carro();
        Iprocesso processo2 = new Caminhao();
        Iprocesso processo3 = new Moto();
        Iprocesso processo4 = new Aviao();

        processo1.setNextHandler(processo2);
        processo2.setNextHandler(processo3);
        processo3.setNextHandler(processo4);

        processo1.runiprocesso();



    }
}