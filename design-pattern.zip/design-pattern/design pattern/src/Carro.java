package src;

public class Carro extends Iprocesso {
    @Override
    public void runiprocesso() {
        System.out.println("Ligando o carro... (Processo1)");

        if (iprocesso != null) {
            iprocesso.runiprocesso();
        }


    }
}