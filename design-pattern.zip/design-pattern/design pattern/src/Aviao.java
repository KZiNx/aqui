package src;

public class Aviao extends Iprocesso {
    @Override
    public void runiprocesso() {
        System.out.println("Colocando combustivel... (Processo4)");

        if (iprocesso != null) {
            iprocesso.runiprocesso();
        }


    }
}