package src;

public class Caminhao extends Iprocesso {
    @Override
    public void runiprocesso() {
        System.out.println("Alocando Bi-Trem... (Processo2)");

        if (iprocesso != null) {
            iprocesso.runiprocesso();
        }


    }
}